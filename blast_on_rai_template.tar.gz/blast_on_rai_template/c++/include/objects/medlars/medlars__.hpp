#include <objects/medlars/Medlars_entry.hpp>
#include <objects/medlars/Medlars_record.hpp>
#include <objects/medlars/NCBI_Medlars_module.hpp>
